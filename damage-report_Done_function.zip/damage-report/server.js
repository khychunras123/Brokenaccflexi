const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Tell Express to serve files from the "public" folder, using login.html as the default index
app.use(express.static(path.join(__dirname, 'public'), { index: 'login.html' }));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
