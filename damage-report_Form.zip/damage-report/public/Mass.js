// Mass.js
function Mass({ data }) {
  if (!data) {
    return null; // Don't show anything if no data has been submitted yet
  }

  return (
    <div className="mt-6 mb-6 p-6 bg-[#00c77e]/10 border border-[#00c77e]/50 rounded-lg animate-pulse">
      <div className="flex items-center gap-3 mb-4">
        <span className="material-symbols-outlined text-[#00c77e]">check_circle</span>
        <span className="font-bold text-[#00c77e]">របាយការណ៍ត្រូវបានបញ្ជូនដោយជោគជ័យ! (Submission Successful)</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-4 text-sm bg-[#111417]/80 p-4 rounded-lg border border-[#363C4E]/50 text-[#d3c5ad] font-['Manrope']">
        <div><span className="text-[#929AA5]">ID:</span> <span className="text-white">AUTO-001</span></div>
        <div><span className="text-[#929AA5]">Team:</span> <span className="text-white">{data.teamPage || "មិនមាន"}</span></div>
        <div><span className="text-[#929AA5]">Branch:</span> <span className="text-[#F3BA2F] font-bold">{data.branch || "មិនមាន"}</span></div>
        <div><span className="text-[#929AA5]">Name:</span> <span className="text-white">{data.name || "មិនមាន"}</span></div>
        <div><span className="text-[#929AA5]">Phone:</span> <span className="text-white">{data.phone || "មិនមាន"}</span></div>
        <div><span className="text-[#929AA5]">Purchase:</span> <span className="text-white">{data.purchaseDate || "មិនមាន"}</span></div>
        <div><span className="text-[#929AA5]">Received:</span> <span className="text-white">{data.receivedDate || "មិនមាន"}</span></div>
        <div className="col-span-1 sm:col-span-2"><span className="text-[#929AA5]">Product:</span> <span className="text-white">{data.productName || "មិនមាន"}</span></div>
        <div className="col-span-1 sm:col-span-2"><span className="text-[#929AA5]">Problem:</span> <span className="text-white whitespace-pre-wrap">{data.problemDesc || "មិនមាន"}</span></div>
        
        <div className="col-span-1 sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
          <div>
            <span className="text-[#929AA5] block mb-2">Invoice:</span> 
            {data.invoice ? <img src={data.invoice} className="w-full h-auto max-h-48 object-cover bg-[#0B0E11] border border-[#363C4E] rounded" alt="Invoice Preview" /> : <span className="text-white">គ្មាន (No)</span>}
          </div>
          <div>
            <span className="text-[#929AA5] block mb-2">Photo:</span> 
            {data.photo ? <img src={data.photo} className="w-full h-auto max-h-48 object-cover bg-[#0B0E11] border border-[#363C4E] rounded" alt="Photo Preview" /> : <span className="text-white">គ្មាន (No)</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
